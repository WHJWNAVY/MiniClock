#ifndef __DRV_LED_H__
#define __DRV_LED_H__

#include "common.h"

typedef enum led_seg_e
{
  LED_SEG_MIN = 0,
  LED_SEG_0 = 0,
  LED_SEG_1,
  LED_SEG_2,
  LED_SEG_3,
  LED_SEG_4,
  LED_SEG_5,
  LED_SEG_6,
  LED_SEG_7,
  LED_SEG_8,
  LED_SEG_9,
  LED_SEG_A,
  LED_SEG_b,
  LED_SEG_C,
  LED_SEG_d,
  LED_SEG_E,
  LED_SEG_F,
  LED_SEG_P,
  LED_SEG_S,
  LED_SEG_PN1,
  LED_SEG_PN2,
  LED_SEG_PN3,
  LED_SEG_PN4,
  LED_SEG_PN5,
  LED_SEG_PN6,
  LED_SEG_PN7,
  LED_SEG_PN8,
  LED_SEG_NULL,
  LED_SEG_MAX,
} led_seg_t;

typedef enum led_num_mod_e
{
  LED_SEG_NUM_OCT = 0,  //ʮ����ģʽ
  LED_SEG_NUM_HEX,      //ʮ������ģʽ
}led_num_mod_t;

typedef enum led_dot_mod_e
{
  LED_SEG_DOT_TURN = 0, //��ˮ��ģʽ
  LED_SEG_NUM_COUNT,    //�����Ƽ���ģʽ
}led_dot_mod_t;

extern void led_init(void);
extern void led_update(void);
extern void led_putc(uchar pos, uchar ch);
extern void led_puts(const uchar* chs);
extern void led_putn(uint num, uchar mod);
extern void led_putdot(uchar num, uchar mod);

#endif