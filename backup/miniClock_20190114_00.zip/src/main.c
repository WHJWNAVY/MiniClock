#include "common.h"
#include "drv_led.h"
#include "drv_key.h"
#include "drv_1302.h"

typedef enum page_mode_e
{
  PAGE_MODE_MIN = 0x1Au,
  PAGE_MODE_MAIN = PAGE_MODE_MIN,
  PAGE_MODE_SET,
  PAGE_MODE_MAX,
} page_mode_e;

typedef enum main_page_e
{
  MAIN_PAGE_MIN = 0x2Au,
  MAIN_PAGE_HHMM = MAIN_PAGE_MIN, //hour - minute
  MAIN_PAGE_TTSS, // am/pm - second
  MAIN_PAGE_YYYY, // year
  MAIN_PAGE_MMDD, // month - day
  MAIN_PAGE_DDDD, // week
  MAIN_PAGE_MAX,
} main_page_t;

typedef enum set_page_e
{
  SET_PAGE_MIN = 0x3Au,
  SET_PAGE_HOUR = SET_PAGE_MIN, //hour - minute
  SET_PAGE_MINUTE, // minute
  SET_PAGE_SECOND, // second
  SET_PAGE_YEAR, // year
  SET_PAGE_MONTH, // month
  SET_PAGE_DAY, // day
  SET_PAGE_WEEK, // week
  SET_PAGE_MAX,
} set_page_t;

typedef enum set_oper_e
{
  SET_OPER_MIN = 0x4Au,
  SET_OPER_ADD,
  SET_OPER_SUB,
  SET_OPER_MAX,
} set_oper_t;

void _menu_data_deal_(uchar* dat, uchar op, uchar max, uchar min)
{
  char data_t = 0;
  if((op == SET_OPER_ADD) || (op == SET_OPER_SUB))
  {
    data_t = (char)(*dat);
    if(op == SET_OPER_ADD)//��
    {
        data_t++;
        if(data_t > max)
        {
            data_t = min;
        }
    }
    else if(op == SET_OPER_SUB)///��
    {
        data_t--;
        if(data_t < min)
        {
            data_t = max;
        }
    }
    *dat = (uchar)data_t;
  }
}

void show_main_page(rtc_time_t* tm, uchar page)
{
  uchar n = 0;
  if(tm == NULL)
  {
    return;
  }
  
  switch(page)
  {
    case MAIN_PAGE_HHMM:
      //n = tm->hour * 100 + tm->minute;
      //led_putn(n, LED_SEG_NUM_OCT);
      //tm->hour   = tm->hour % 100;
      //tm->minute = tm->minute % 100;
      led_putc(0, (tm->hour / 10));
      led_putc(1, (tm->hour % 10));
      led_putc(2, (tm->minute / 10));
      led_putc(3, (tm->minute % 10));
      break;
    case MAIN_PAGE_TTSS:
      //tm->hour   = tm->hour % 100;
      //tm->second = tm->second % 100;
      n = (tm->hour >= 12) ? LED_SEG_P : LED_SEG_A;
      led_putc(0, n);
      led_putc(1, LED_SEG_NULL);
      led_putc(2, (tm->second / 10));
      led_putc(3, (tm->second % 10));
      break;
    case MAIN_PAGE_YYYY:
      //tm->year = tm->year % 100;
      led_putc(0, 2);
      led_putc(1, 0);
      led_putc(2, (tm->year / 10));
      led_putc(3, (tm->year % 10));
      break;
    case MAIN_PAGE_MMDD:
      //tm->month = tm->month % 100;
      //tm->day   = tm->day % 100;
      led_putc(0, (tm->month / 10));
      led_putc(1, (tm->month % 10));
      led_putc(2, (tm->day / 10));
      led_putc(3, (tm->day % 10));
      break;
    case MAIN_PAGE_DDDD:
      led_putc(0, (LED_SEG_NULL));
      led_putc(1, (LED_SEG_NULL));
      led_putc(2, (LED_SEG_NULL));
      led_putc(3, (tm->week % 10));
      break;
    default:
      break;
  }
}

void show_set_page(rtc_time_t* tm, uchar page, uchar op)
{
  uchar n = 0;
  uchar dat = 0;
  if(tm == NULL)
  {
    return;
  }
  
  switch(page)
  {
    case SET_PAGE_HOUR:
      dat = tm->hour;
      _menu_data_deal_(&dat, op, 23, 0);
      tm->hour = dat;
      break;
    case SET_PAGE_MINUTE:
      dat = tm->minute;
      _menu_data_deal_(&dat, op, 59, 0);
      tm->minute = dat;
      break;
    case SET_PAGE_SECOND:
      dat = tm->second;
      _menu_data_deal_(&dat, op, 59, 0);
      tm->second = dat;
      break;
    case SET_PAGE_YEAR:
      dat = tm->year;
      _menu_data_deal_(&dat, op, 99, 0);
      tm->year = dat;
      break;
    case SET_PAGE_MONTH:
      dat = tm->month;
      _menu_data_deal_(&dat, op, 12, 1);
      tm->month = dat;
      break; 
    case SET_PAGE_DAY:
      dat = tm->day;
      _menu_data_deal_(&dat, op, 31, 1);
      tm->day = dat;
      break;
    case SET_PAGE_WEEK:
      dat = tm->week;
      _menu_data_deal_(&dat, op, 7, 1);
      tm->week = dat;
      break;
    default:
      break;
  }

  led_putc(0, LED_SEG_S);
  led_putc(1, (page - SET_PAGE_MIN + LED_SEG_PN1));
  led_putc(2, dat / 10);
  led_putc(3, dat % 10);
}

void main(void)
{
  uchar i = 0;
  uchar key_code = 0;
  uchar page_mode_cnt = PAGE_MODE_MIN;
  uchar main_page_cnt = MAIN_PAGE_MIN;
  uchar set_page_cnt = SET_PAGE_MIN;
  uchar set_oper = SET_OPER_MIN;
  rtc_time_t time_t = {0};
  rtc_time_t time_set = {0};

  key_init();
  led_init();
  rtc_init();
  led_putn(1234, LED_SEG_NUM_OCT);

  while(1)
  {
    key_code = key_get();

    set_oper = SET_OPER_MIN;

    if(key_code != KEY_BTN_NULL)
    {
      switch(key_code)
      {
        case KEY_BTN_SET_LP:
          {
            page_mode_cnt++;
            if(page_mode_cnt >= PAGE_MODE_MAX)
            {
              page_mode_cnt = PAGE_MODE_MIN;
            }
            
            if(page_mode_cnt == PAGE_MODE_SET)
            {
              set_page_cnt = SET_PAGE_MIN;
              rtc_read_time(&time_set);
            }
            
            if(page_mode_cnt == PAGE_MODE_MAIN)
            {
              main_page_cnt = MAIN_PAGE_MIN;
              rtc_set_time(&time_set);
            }
          }
          break;
        case KEY_BTN_SET:
          {
            if(page_mode_cnt == PAGE_MODE_MAIN)
            {
              main_page_cnt++;
              if(main_page_cnt >= MAIN_PAGE_MAX)
              {
                main_page_cnt = MAIN_PAGE_MIN;
              }
            }
            if(page_mode_cnt == PAGE_MODE_SET)
            {
              set_page_cnt++;
              if(set_page_cnt >= SET_PAGE_MAX)
              {
                set_page_cnt = SET_PAGE_MIN;
                #if 1
                page_mode_cnt = PAGE_MODE_MAIN;
                main_page_cnt = MAIN_PAGE_MIN;
                #endif
              }
            }
          }
          break;
        case KEY_BTN_UP:
          {
            if(page_mode_cnt == PAGE_MODE_SET)
            {
              set_oper = SET_OPER_ADD;
            }
          }
          break;
        case KEY_BTN_DWN:
          {
            if(page_mode_cnt == PAGE_MODE_SET)
            {
              set_oper = SET_OPER_SUB;
            }
          }
          break;
        default:
          break;
      }
    }

    rtc_read_time(&time_t);

    switch(page_mode_cnt)
    {
      case PAGE_MODE_MAIN:   
        show_main_page(&time_t, main_page_cnt);
        break;
      case PAGE_MODE_SET:
        show_set_page(&time_set, set_page_cnt, set_oper);
        break;
      default:
        break;
    }

    led_update();
  }
}

