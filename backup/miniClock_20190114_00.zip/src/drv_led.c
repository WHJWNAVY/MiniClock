#include "drv_led.h"

sbit LED_SEL_3   = P2 ^ 3;
sbit LED_SEL_2   = P2 ^ 4;
sbit LED_SEL_1   = P2 ^ 5;
sbit LED_SEL_0   = P2 ^ 6;

#define LED_SEG_PORT          P1
#define LED_POS_PORT          P2

#define LED_POS_MAX           (4u)
//#define LED_SEG_MAX           (17u)
#define LED_DISP_DELAY        (400u)

#define LED_SEG_NUM_HEX_MAX   (0xFFFFu)
#define LED_SEG_NUM_OCT_MAX   (9999u)

#define LED_POS_SET(pos, val)       \
do{                                 \
  switch(pos)                       \
  {                                 \
    case 0:                         \
      LED_SEL_0 = ((val) ? 1 : 0);  \
      LED_SEL_1 = ((val) ? 0 : 1);  \
      LED_SEL_2 = ((val) ? 0 : 1);  \
      LED_SEL_3 = ((val) ? 0 : 1);  \
      break;                        \
    case 1:                         \
      LED_SEL_0 = ((val) ? 0 : 1);  \
      LED_SEL_1 = ((val) ? 1 : 0);  \
      LED_SEL_2 = ((val) ? 0 : 1);  \
      LED_SEL_3 = ((val) ? 0 : 1);  \
      break;                        \
    case 2:                         \
      LED_SEL_0 = ((val) ? 0 : 0);  \
      LED_SEL_1 = ((val) ? 0 : 1);  \
      LED_SEL_2 = ((val) ? 1 : 0);  \
      LED_SEL_3 = ((val) ? 0 : 1);  \
      break;                        \
    case 3:                         \
      LED_SEL_0 = ((val) ? 0 : 1);  \
      LED_SEL_1 = ((val) ? 0 : 1);  \
      LED_SEL_2 = ((val) ? 0 : 1);  \
      LED_SEL_3 = ((val) ? 1 : 0);  \
      break;                        \
    default:                        \
      break;                        \
  }                                 \
}while(0)

#define LED_SEG_SET(seg)          do{LED_SEG_PORT = (seg);}while(0)

uchar LED_DISP[LED_POS_MAX] = {0};

const uchar LED_SEG[LED_SEG_MAX] =
{
#if 0
#if 0
  /*����ʮ������*/
	0x3F,/*0*/
	0x06,/*1*/
	0x5B,/*2*/
	0x4F,/*3*/
	0x66,/*4*/
	0x6D,/*5*/
	0x7D,/*6*/
	0x07,/*7*/
	0x7F,/*8*/
	0x6F,/*9*/
	0x77,/*A*/
	0x5F,/*a*/
	0x7F,/*B*/
	0x7C,/*b*/
	0x39,/*C*/
	0x58,/*c*/
	0x3F,/*D*/
	0x5E,/*d*/
	0x79,/*E*/
	0x7B,/*e*/
	0x71,/*F*/
	0x71,/*f*/
	0x7D,/*G*/
	0x6F,/*g*/
	0x76,/*H*/
	0x74,/*h*/
	0x06,/*I*/
	0x04,/*i*/
	0x1E,/*J*/
	0x1E,/*j*/
	0x38,/*L*/
	0x06,/*l*/
	0x37,/*N*/
	0x54,/*n*/
	0x3F,/*O*/
	0x5C,/*o*/
	0x73,/*P*/
	0x73,/*p*/
	0x67,/*Q*/
	0x67,/*q*/
	0x77,/*R*/
	0x50,/*r*/
	0x6D,/*S*/
	0x6D,/*s*/
	0x31,/*T*/
	0x78,/*t*/
	0x3E,/*U*/
	0x1C,/*u*/
	0x6E,/*Y*/
	0x6E,/*y*/
	0x5B,/*Z*/
	0x5B,/*z*/
	0x40,/*-*/
	0x08,/*_*/
	0x80,/*.*/
#else
  /*����ʮ������*/
	0xC0,/*0*/
	0xF9,/*1*/
	0xA4,/*2*/
	0xB0,/*3*/
	0x99,/*4*/
	0x92,/*5*/
	0x82,/*6*/
	0xF8,/*7*/
	0x80,/*8*/
	0x90,/*9*/
	0x88,/*A*/
	0xA0,/*a*/
	0x80,/*B*/
	0x83,/*b*/
	0xC6,/*C*/
	0xA7,/*c*/
	0xC0,/*D*/
	0xA1,/*d*/
	0x86,/*E*/
	0x84,/*e*/
	0x8E,/*F*/
	0x8E,/*f*/
	0x82,/*G*/
	0x90,/*g*/
	0x89,/*H*/
	0x8B,/*h*/
	0xF9,/*I*/
	0xFB,/*i*/
	0xE1,/*J*/
	0xE1,/*j*/
	0xC7,/*L*/
	0xF9,/*l*/
	0xC8,/*N*/
	0xAB,/*n*/
	0xC0,/*O*/
	0xA3,/*o*/
	0x8C,/*P*/
	0x8C,/*p*/
	0x98,/*Q*/
	0x98,/*q*/
	0x88,/*R*/
	0xAF,/*r*/
	0x92,/*S*/
	0x92,/*s*/
	0xCE,/*T*/
	0x87,/*t*/
	0xC1,/*U*/
	0xE3,/*u*/
	0x91,/*Y*/
	0x91,/*y*/
	0xA4,/*Z*/
	0xA4,/*z*/
	0xBF,/*-*/
	0xF7,/*_*/
	0x7F,/*.*/
#endif
#else
	0xC0,/*0*/
	0xF9,/*1*/
	0xA4,/*2*/
	0xB0,/*3*/
	0x99,/*4*/
	0x92,/*5*/
	0x82,/*6*/
	0xF8,/*7*/
	0x80,/*8*/
	0x90,/*9*/
	0x88,/*A*/
	0x83,/*b*/
	0xC6,/*C*/
	0xA1,/*d*/
	0x86,/*E*/
	0x8E,/*F*/
  0x8C,/*P*/
	0x92,/*S*/
  0xFE,/*POINT1*/
  0xFD,/*POINT2*/
  0xFB,/*POINT3*/
  0xF7,/*POINT4*/
  0xEF,/*POINT5*/
  0xDF,/*POINT6*/
  0xBF,/*POINT7*/
  0x7F,/*POINT8*/
  0xFF,/*NULL*/
#endif
};

#if 0
void timer0_init(void)		//10����@11.0592MHz
{
	//AUXR &= 0x7F;		//��ʱ��ʱ��12Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TMOD |= 0x01;		//���ö�ʱ��ģʽ
	TL0 = 0x00;		  //���ö�ʱ��ֵ
	TH0 = 0xDC;		  //���ö�ʱ��ֵs
	TF0 = 0;		    //���TF0��־
	
  ET0 = 1;        //ʹ�ܶ�ʱ��0�ж�
  EA  = 1;        //ʹ�����ж�

  TR0 = 1;		    //��ʱ��0��ʼ��ʱ
}
#endif

void led_init(void)
{
  uchar i = 0;

  LED_SEG_PORT = 0;
  LED_POS_PORT = 0;

  for(i=0; i<LED_POS_MAX; i++)
  {
    LED_DISP[i] = LED_SEG[0x0Au];
  }

  //timer0_init();
}

void led_update(void)
{
  uchar i = 0;

  for(i=0; i<LED_POS_MAX; i++)
  {
    LED_SEG_SET(LED_DISP[i]);
    LED_POS_SET(i, 1);
    delay_xus(LED_DISP_DELAY);
  }
}

#if 0
void led_timer0(void) interrupt 1
{
	TL0 = 0x00;		  //���ö�ʱ��ֵ
	TH0 = 0xDC;		  //���ö�ʱ��ֵ
	TF0 = 0;		    //���TF0��־
  led_update();
}
#endif

void led_putc(uchar pos, uchar ch)
{
  if((pos >= LED_POS_MAX) || (ch >= LED_SEG_MAX))
  {
    return;
  }
  LED_DISP[pos] = LED_SEG[ch];
}

void led_puts(const uchar* chs)
{
  uchar i = 0;
  if(chs == NULL)
  {
    return ;
  }
  for(i=0; i<LED_POS_MAX; i++)
  {
    led_putc(i, chs[i]);
  }
}

void led_putn(uint num, uchar mod)
{
  uchar i = 0;
  uchar seg_arr[LED_POS_MAX] = {0};
  if(mod) // hex mode
  {
    if(num > LED_SEG_NUM_HEX_MAX)
    {
      return;
    }

    for(i=0; i<LED_POS_MAX; i++)
    {
      seg_arr[LED_POS_MAX - i - 1] = (num & 0x0Fu);
      num = (num >> 4);
    }
  }
  else
  {
    if(num > LED_SEG_NUM_OCT_MAX)
    {
      return;
    }
    
    for(i=0; i<LED_POS_MAX; i++)
    {
      seg_arr[LED_POS_MAX - i - 1] = num % 10;
      num = (num / 10);
    }
  }
  
  led_puts(seg_arr);
}

//bug ��ʾ��֮�����־Ͳ���������ʾ
void led_putdot(uchar num, uchar mod)
{
  uchar i = 0;
  if(mod)
  {
    if(num > ((0x01 << LED_POS_MAX) - 1))
    {
      return;
    }
    for(i=0; i<LED_POS_MAX; i++)
    {
      if(num & 0x01)
      {
        LED_DISP[LED_POS_MAX - i - 1] &= /*((uchar)(~0x80))*/0x7Fu;
      }
      else
      {
        LED_DISP[LED_POS_MAX - i - 1] |= ((uchar)0x80u);
      }
      num = num >> 1;
    }
  }
  else
  {
    if(num >= LED_POS_MAX)
    {
      return;
    }
    for(i=0; i<LED_POS_MAX; i++)
    {
      if(i == num)
      {
        LED_DISP[i] &= /*((uchar)(~0x80))*/0x7Fu;
      }
      else
      {
        LED_DISP[i] |= ((uchar)0x80u);
      }
    }
  }
}
