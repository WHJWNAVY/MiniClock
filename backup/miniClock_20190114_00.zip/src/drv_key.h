#ifndef __DRV_KEY_H__
#define __DRV_KEY_H__

#include "common.h"

typedef enum key_btn_e
{
  KEY_BTN_NULL = 0xFFu,   //short press
  KEY_BTN_SET  = 0xAAu,
  KEY_BTN_UP   = 0xBBu,
  KEY_BTN_DWN  = 0xCCu,
  
  KEY_BTN_SET_LP  = 0xABu, //long press
  KEY_BTN_UP_LP   = 0xBCu,
  KEY_BTN_DWN_LP  = 0xCDu,
} key_btn_t;

extern void key_init(void);
extern uchar key_get(void);

#endif