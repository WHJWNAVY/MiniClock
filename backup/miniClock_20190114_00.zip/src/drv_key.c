#include "drv_key.h"

sbit KEY_BTN_0 = P3^5;
sbit KEY_BTN_1 = P3^6;
sbit KEY_BTN_2 = P3^7;

#define KEY_BTN_PORT            P3

#define KEY_BTN_LONG_PRESS_CNT  (40u) //2S

uint16 key_timer_cnt = 0;

void timer1_init(void)		//50����@11.0592MHz
{
	//AUXR &= 0xBF;		      //��ʱ��ʱ��12Tģʽ
	TMOD &= 0x0F;		      //���ö�ʱ��ģʽ
	TMOD |= 0x10;		      //���ö�ʱ��ģʽ
	TL1 = 0x00;		        //���ö�ʱ��ֵ
	TH1 = 0x4C;		        //���ö�ʱ��ֵ
	TF1 = 0;		          //���TF1��־
  ET1 = 1;              //ʹ�ܶ�ʱ��0�ж�
  EA  = 1;              //ʹ�����ж�

  TR1 = 1;		          //��ʱ��1��ʼ��ʱ
}

void key_timer1(void) interrupt 3
{
	TL1 = 0x00;		        //���ö�ʱ��ֵ
	TH1 = 0x4C;		        //���ö�ʱ��ֵ
	TF1 = 0;		          //���TF1��־
  
  key_timer_cnt++;
}

void key_init(void)
{
  key_timer_cnt = 0;
  timer1_init();
}

uchar key_get(void)
{
  KEY_BTN_PORT = 0xFFu;
  if((KEY_BTN_0 == 0) || (KEY_BTN_1 == 0) || (KEY_BTN_2 == 0))
  {
    delay_xus(50);
    if(KEY_BTN_0 == 0)
    {
      key_timer_cnt = 0;
      while(KEY_BTN_0 == 0);
      if(key_timer_cnt >= KEY_BTN_LONG_PRESS_CNT)
      {
        return KEY_BTN_SET_LP;
      }
      else
      {
        return KEY_BTN_SET;
      }
    }
    
    if(KEY_BTN_1 == 0)
    {
      key_timer_cnt = 0;
      while(KEY_BTN_1 == 0);
      if(key_timer_cnt >= KEY_BTN_LONG_PRESS_CNT)
      {
        return KEY_BTN_UP_LP;
      }
      else
      {
        return KEY_BTN_UP;
      }
    }
    
    if(KEY_BTN_2 == 0)
    {
      key_timer_cnt = 0;
      while(KEY_BTN_2 == 0);
      if(key_timer_cnt >= KEY_BTN_LONG_PRESS_CNT)
      {
        return KEY_BTN_DWN_LP;
      }
      else
      {
        return KEY_BTN_DWN;
      }
      
    }
  }
  
  return KEY_BTN_NULL;
}