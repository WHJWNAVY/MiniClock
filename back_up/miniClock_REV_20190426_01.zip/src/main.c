#include "common.h"
#include "drv_led.h"
#include "drv_key.h"
#include "drv_3231.h"
#include "drv_18b20.h"
//#include "drv_temp.h"
//#include "drv_ds18b20.h"

#define DEF_SYS_LED_FPS      (100u)
#define DEF_SYS_LED_FLASH    (3u)
#define DEF_SYS_LED_MIRROR   (1u)

typedef enum page_mode_e
{
    PAGE_MODE_MIN = 0x1Au,
    PAGE_MODE_MAIN = PAGE_MODE_MIN,//������
    PAGE_MODE_STIME,//ʱ�����ý���
    PAGE_MODE_SDATE,//�������ý���
    PAGE_MODE_MAX,
} page_mode_e;

typedef enum main_page_e
{
    MAIN_PAGE_MIN = 0x2Au,
    MAIN_PAGE_HHMM = MAIN_PAGE_MIN, //hour - minute
    MAIN_PAGE_TTSS, // am/pm - second
    MAIN_PAGE_YYYY, // year
    MAIN_PAGE_MMDD, // month - day
    MAIN_PAGE_DDDD, // week
    MAIN_PAGE_MAX,
} main_page_t;

typedef enum set_time_page_e
{
    SET_TIME_PAGE_MIN = 0x3Au,
    SET_TIME_PAGE_HOUR = SET_TIME_PAGE_MIN, //hour
    SET_TIME_PAGE_MINUTE,   // minute
    SET_TIME_PAGE_SECOND,   // second
    SET_TIME_PAGE_MAX,
} set_time_page_t;

typedef enum set_date_page_e
{
    SET_DATE_PAGE_MIN = 0x4Au,
    SET_DATE_PAGE_YEAR = SET_DATE_PAGE_MIN, // year
    SET_DATE_PAGE_WEEK,     // week
    SET_DATE_PAGE_MONTH,    // month
    SET_DATE_PAGE_DAY,      // day
    SET_DATE_PAGE_MAX,
} set_date_page_t;

typedef enum set_oper_e
{
    SET_OPER_MIN = 0x5Au,
    SET_OPER_ADD,
    SET_OPER_SUB,
    SET_OPER_MAX,
} set_oper_t;

void _menu_data_deal_(uchar *dat, uchar op, uchar max, uchar min)
{
    char data_t = 0;
    if((op == SET_OPER_ADD) || (op == SET_OPER_SUB))
    {
        data_t = (char)(*dat);
        if(op == SET_OPER_ADD)//��
        {
            data_t++;
            if(data_t > max)
            {
                data_t = min;
            }
        }
        else if(op == SET_OPER_SUB)///��
        {
            data_t--;
            if(data_t < min)
            {
                data_t = max;
            }
        }
        *dat = (uchar)data_t;
    }
}

void show_main_page(rtc_time_t *tm, uchar page)
{
    uchar n = 0;
    char disp_str[LED_POS_MAX+1] = {0};
    if(tm == NULL)
    {
        return;
    }

    switch(page)
    {
    case MAIN_PAGE_HHMM:
        tm->hour   = tm->hour % 100;
        tm->minute = tm->minute % 100;

        led_puti(0, (tm->hour / 10), 1);
        led_puti(1, (tm->hour % 10), 1);
        led_puti(2, (tm->minute / 10), 1);
        led_puti(3, (tm->minute % 10), 1);

        //sprintf(disp_str, "%bu%bu%bu%bu", (tm->hour / 10), (tm->hour % 10), (tm->minute / 10), (tm->minute % 10));
        //led_puts(0, disp_str, 1);

        for(n=0; n<LED_POS_MAX; n++)
        {
            if(((tm->second) % LED_POS_MAX) == n)
            {
                led_putb(n, LED_SEGB_SET(LED_SEGB_DP), 1, 1);
            }
            else
            {
                led_putb(n, LED_SEGB_SET(LED_SEGB_DP), 0, 1);
            }
        }
        break;
    case MAIN_PAGE_TTSS:
        tm->second = tm->second % 100;

        led_puti(0, LED_SEG_NULL, 1);
        led_puti(1, (tm->second / 10), 1);
        led_puti(2, (tm->second % 10), 1);
        led_puti(3, LED_SEG_NULL, 1);

        //sprintf(disp_str, " %bu%bu ", (tm->second / 10), (tm->second % 10));
        //led_puts(0, disp_str, 1);
        break;
    case MAIN_PAGE_YYYY:
        tm->year = tm->year % 100;

        led_puti(0, 2, 1);
        led_puti(1, 0, 1);
        led_puti(2, (tm->year / 10), 1);
        led_puti(3, (tm->year % 10), 1);

        //sprintf(disp_str, "20%bu%bu", (tm->year / 10), (tm->year % 10));
        //led_puts(0, disp_str, 1);
        break;
    case MAIN_PAGE_MMDD:
        tm->month = tm->month % 100;
        tm->day   = tm->day % 100;

        led_puti(0, (tm->month / 10), 1);
        led_puti(1, (tm->month % 10), 1);
        led_puti(2, (tm->day / 10), 1);
        led_puti(3, (tm->day % 10), 1);

        //sprintf(disp_str, "%bu%bu%bu%bu", (tm->month / 10), (tm->month % 10), (tm->day / 10), (tm->day % 10));
        //led_puts(0, disp_str, 1);
        break;
    case MAIN_PAGE_DDDD:
        tm->week   = tm->week % 100;

        led_puti(0, (LED_SEG_NULL), 1);
        led_puti(1, (LED_SEG_EFG), 1);
        led_puti(2, (tm->week % 10), 1);
        led_puti(3, (LED_SEG_BCG), 1);

        //sprintf(disp_str, " {%bu}", /*(((tm->week % 10) > 5) ? "-" : " "),*/ (tm->week % 10));
        //led_puts(0, disp_str, 1);
        break;
    default:
        break;
    }
}

void show_time_set_page(rtc_time_t *tm, uchar page, uchar op)
{
    uchar dat = 0;
    char disp_str[LED_POS_MAX+1] = {0};

    if(tm == NULL)
    {
        return;
    }

    switch(page)
    {
    case SET_TIME_PAGE_HOUR:
        dat = tm->hour;
        _menu_data_deal_(&dat, op, 23, 0);
        tm->hour = dat;
        break;
    case SET_TIME_PAGE_MINUTE:
        dat = tm->minute;
        _menu_data_deal_(&dat, op, 59, 0);
        tm->minute = dat;
        break;
    case SET_TIME_PAGE_SECOND:
        dat = tm->second;
        _menu_data_deal_(&dat, op, 59, 0);
        tm->second = dat;
        break;
    default:
        break;
    }

    page = page - SET_TIME_PAGE_MIN;

    disp_str[0] = LED_SEG_H;

    //page %= (LED_SEG_SG - LED_SEG_SA + 1);
    disp_str[1] = page + 1;

    //dat %= 100;
    disp_str[2] = dat / 10;
    disp_str[3] = dat % 10;
    led_putis(0, disp_str, LED_POS_MAX, 1);
}

void show_date_set_page(rtc_time_t *tm, uchar page, uchar op)
{
    uchar n = 0;
    uchar dat = 0;
    char disp_str[LED_POS_MAX+1] = {0};

    if(tm == NULL)
    {
        return;
    }

    switch(page)
    {
    case SET_DATE_PAGE_YEAR:
        dat = tm->year;
        _menu_data_deal_(&dat, op, 99, 0);
        tm->year = dat;
        break;
    case SET_DATE_PAGE_MONTH:
        dat = tm->month;
        _menu_data_deal_(&dat, op, 12, 1);
        tm->month = dat;
        break;
    case SET_DATE_PAGE_DAY:
        dat = tm->day;
        _menu_data_deal_(&dat, op, 31, 1);
        tm->day = dat;
        break;
    case SET_DATE_PAGE_WEEK:
        n = 1;
        dat = tm->week;
        _menu_data_deal_(&dat, op, 7, 1);
        tm->week = dat;
        break;
    default:
        break;
    }

    page = page - SET_DATE_PAGE_MIN;

    disp_str[0] = LED_SEG_P;

    //page %= (LED_SEG_SG - LED_SEG_SA + 1);
    disp_str[1] = page + 1;

    //dat %= 100;
    disp_str[2] = dat / 10;
    disp_str[3] = dat % 10;
    led_putis(0, disp_str, LED_POS_MAX, 1);
}

void main(void)
{
    uchar i = 0, j = 0;
    uchar key_code = 0;
    uchar page_mode_cnt = PAGE_MODE_MIN;
    uchar main_page_cnt = MAIN_PAGE_MIN;
    uchar settime_page_cnt = SET_TIME_PAGE_MIN;
    uchar setdate_page_cnt = SET_DATE_PAGE_MIN;
    uchar set_oper = SET_OPER_MIN;
    rtc_time_t time_t = {19,1,4,22,0,0,0};
    rtc_time_t time_set = {19,1,4,22,10,30,0};
    rtc_time_t date_set = {19,1,4,22,10,30,0};
    uint8 main_timer = 0;

    key_init();
    led_init();
    ds3231_init();

    led_set_mirror(DEF_SYS_LED_MIRROR);
    key_set_mirror(DEF_SYS_LED_MIRROR);
    led_open_door(50);
    led_close_door(50);

#if 1
    while(1)
    {
        //main_timer++;
        key_code = key_get_code();

        set_oper = SET_OPER_MIN;

        if(key_code != KEY_BTN_NULL)
        {
            //main_timer = 0;
            switch(key_code)
            {
            case KEY_BTN_NEXT_PAGE://��һ������
            {
                page_mode_cnt++;
                if(page_mode_cnt >= PAGE_MODE_MAX)
                {
                    page_mode_cnt = PAGE_MODE_MIN;
                }

                if(page_mode_cnt == PAGE_MODE_MAIN)
                {
                    main_page_cnt = MAIN_PAGE_MIN;
                    led_set_flashc(2, 0);
                    led_set_flashc(3, 0);
                }

                //��������ʱ�����
                if(page_mode_cnt == PAGE_MODE_STIME)
                {
                    settime_page_cnt = SET_TIME_PAGE_MIN;
                    ds3231_read_time(&time_set);
                    //�������ý������������˸
                    led_set_flashc(2, DEF_SYS_LED_FLASH);
                    led_set_flashc(3, DEF_SYS_LED_FLASH);
                }

                //�����������ڽ���
                if(page_mode_cnt == PAGE_MODE_SDATE)
                {
                    setdate_page_cnt = SET_DATE_PAGE_MIN;
                    ds3231_read_time(&date_set);
                    //�������ý������������˸
                    led_set_flashc(2, DEF_SYS_LED_FLASH);
                    led_set_flashc(3, DEF_SYS_LED_FLASH);
                }
            }
            break;
            case KEY_BTN_SAVE_SETT://����
            {
                if(page_mode_cnt == PAGE_MODE_STIME)
                {
                    ds3231_read_time(&date_set);
                    time_set.year = date_set.year;
                    time_set.week = date_set.week;
                    time_set.month = date_set.month;
                    time_set.day = date_set.day;
                    ds3231_set_time(&time_set);
                    //�������ú�������ֹͣ��˸
                    led_set_flashc(2, 0);
                    led_set_flashc(3, 0);
                }

                if(page_mode_cnt == PAGE_MODE_SDATE)
                {
                    ds3231_read_time(&time_set);
                    date_set.hour = time_set.hour;
                    date_set.minute = time_set.minute;
                    date_set.second = time_set.second;
                    ds3231_set_time(&date_set);
                    //�������ú�������ֹͣ��˸
                    led_set_flashc(2, 0);
                    led_set_flashc(3, 0);
                }
            }
            break;
            case KEY_BTN_NEXT_ENTRY://��һ����Ŀ
            {
                if(page_mode_cnt == PAGE_MODE_MAIN)
                {
                    main_page_cnt++;
                    if(main_page_cnt >= MAIN_PAGE_MAX)
                    {
                        main_page_cnt = MAIN_PAGE_MIN;
                    }
                }
                if(page_mode_cnt == PAGE_MODE_STIME)
                {
                    settime_page_cnt++;
                    if(settime_page_cnt >= SET_TIME_PAGE_MAX)
                    {
                        settime_page_cnt = SET_TIME_PAGE_MIN;
                    }
                }
                if(page_mode_cnt == PAGE_MODE_SDATE)
                {
                    setdate_page_cnt++;
                    if(setdate_page_cnt >= SET_DATE_PAGE_MAX)
                    {
                        setdate_page_cnt = SET_DATE_PAGE_MIN;
                    }
                }
            }
            break;
            case KEY_BTN_UP:
            {
                if(page_mode_cnt == PAGE_MODE_MAIN)
                {
                    main_page_cnt++;
                    if(main_page_cnt >= MAIN_PAGE_MAX)
                    {
                        main_page_cnt = MAIN_PAGE_MIN;
                    }
                }
                if((page_mode_cnt == PAGE_MODE_STIME) || 
                   (page_mode_cnt == PAGE_MODE_SDATE))
                {
                    set_oper = SET_OPER_ADD;
                    //���ý����У���������ı����������˸
                    led_set_flashc(2, DEF_SYS_LED_FLASH);
                    led_set_flashc(3, DEF_SYS_LED_FLASH);
                }
            }
            break;
            case KEY_BTN_DWN:
            {
                if(page_mode_cnt == PAGE_MODE_MAIN)
                {
                    main_page_cnt--;
                    if(main_page_cnt < MAIN_PAGE_MIN)
                    {
                        main_page_cnt = MAIN_PAGE_MAX-1;
                    }
                }
                if((page_mode_cnt == PAGE_MODE_STIME) || 
                   (page_mode_cnt == PAGE_MODE_SDATE))
                {
                    set_oper = SET_OPER_SUB;
                    //���ý����У���������ı����������˸
                    led_set_flashc(2, DEF_SYS_LED_FLASH);
                    led_set_flashc(3, DEF_SYS_LED_FLASH);
                }
            }
            break;
            default:
                break;
            }
        }

        ds3231_read_time(&time_t);

        switch(page_mode_cnt)
        {
        case PAGE_MODE_MAIN:
            show_main_page(&time_t, main_page_cnt);
            break;
        case PAGE_MODE_STIME:
            show_time_set_page(&time_set, settime_page_cnt, set_oper);
            break;
        case PAGE_MODE_SDATE:
            show_date_set_page(&date_set, setdate_page_cnt, set_oper);
            break;
        default:
            break;
        }

        set_oper = SET_OPER_MIN;

        led_update();
        delay_xms(DEF_SYS_LED_FPS);
    }
#endif

#if 0
    led_set_mirror(1);

    led_open_door();
    led_close_door();

    led_clear(0);

    led_set_flashc(1, 5);
    led_set_flashc(3, 5);
    led_puts(0, "ABCD", 1);

    while(1)
    {
        led_update();
        delay_xms(100);
    }
#endif

#if 0

    char i = 0, j = 0;

    uchar led_segb[4] =
    {
        LED_SEGB_SET(LED_SEGB_A) | LED_SEGB_SET(LED_SEGB_D) | LED_SEGB_SET(LED_SEGB_G),
        LED_SEGB_SET(LED_SEGB_B) | LED_SEGB_SET(LED_SEGB_C),
        LED_SEGB_SET(LED_SEGB_E) | LED_SEGB_SET(LED_SEGB_F),
        LED_SEGB_SET(LED_SEGB_G) | LED_SEGB_SET(LED_SEGB_B) | LED_SEGB_SET(LED_SEGB_C) | LED_SEGB_SET(LED_SEGB_DP),
    };

    led_init();
    while(1)
    {
        led_clear(0);
        led_update();

        for(i = 0; i < LED_POS_MAX; i++)
        {
            for(j = 0; j < LED_SEGB_MAX; j++)
            {
                led_set_point(i, j, 1);
                led_update();
                delay_xms(50);
            }
        }
        for(i = LED_POS_MAX - 1; i >= 0; i--)
        {
            for(j = LED_SEGB_MAX - 1; j >= 0; j--)
            {
                led_set_point(i, j, 0);
                led_update();
                delay_xms(50);
            }
        }

        led_clear(0);
        led_puts(0, "1234", 1);
        led_update();
        delay_xms(1000);

        led_puts(0, "ABCD", 1);
        led_update();
        delay_xms(1000);

        led_clear(0);

        for(i = 0; i < LED_POS_MAX; i++)
        {
            j = ((i >= 2) ? 0 : 1);
            led_putb(i, led_segb[0], 1, j);
        }
        led_update();
        delay_xms(1000);
        for(i = 0; i < LED_POS_MAX; i++)
        {
            j = ((i >= 2) ? 0 : 1);
            led_putb(i, led_segb[1], 1, j);
        }
        led_update();
        delay_xms(1000);
        for(i = 0; i < LED_POS_MAX; i++)
        {
            j = ((i >= 2) ? 0 : 1);
            led_putb(i, led_segb[2], 1, j);
        }
        led_update();
        delay_xms(1000);
        for(i = 0; i < LED_POS_MAX; i++)
        {
            j = ((i >= 2) ? 0 : 1);
            led_putb(i, led_segb[3], 1, j);
        }
        led_update();
        delay_xms(1000);
    }
#endif


#if 0
    uint8_t sign = 0;
    uint16_t interger = 0;
    uint16_t decimal = 0;
    uchar temp_str[LED_POS_MAX] = {0};
    led_init();
    ds18b20_init();
    led_puts(0, "A1B2", 1);
    led_update();

    while(1)
    {
        ds18b20_get_temp(&sign, &interger, &decimal);
        sprintf(temp_str, "%04d", interger);
        led_puts(0, temp_str, 1);
        led_update();
        delay_xms(100);
    }
#endif
}

