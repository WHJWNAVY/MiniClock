#ifndef __DRV_DS18B20_H_
#define __DRV_DS18B20_H_
#include "common.h"

extern uint8_t ds18b20_init(void);
extern uint16_t ds18b20_get_temp(uint8_t *sign ,uint16_t *interger ,uint16_t *decimal);
#endif















