#include "drv_led.h"

sbit LED_CLK        = P1 ^ 2;
sbit LED_CS         = P1 ^ 3;
sbit LED_DIN        = P1 ^ 4;

#define MAX7219_ADDR_NONE           (0x00)
#define MAX7219_ADDR_DIG0           (0x01)
#define MAX7219_ADDR_DIG1           (0x02)
#define MAX7219_ADDR_DIG2           (0x03)
#define MAX7219_ADDR_DIG3           (0x04)
#define MAX7219_ADDR_DIG4           (0x05)
#define MAX7219_ADDR_DIG5           (0x06)
#define MAX7219_ADDR_DIG6           (0x07)
#define MAX7219_ADDR_DIG7           (0x08)
#define MAX7219_ADDR_DECODE_MODE    (0x09)//����ģʽ
#define MAX7219_ADDR_INTENSITY      (0x0A)//��������
#define MAX7219_ADDR_SCAN_LIMIT     (0x0B)//ɨ����λ
#define MAX7219_ADDR_SHUTDOWN       (0x0C)//�ر���ʾ
#define MAX7219_ADDR_DISPTEST       (0x0F)//����ģʽ

#define MAX7219_DECODE_MODE_NONE    (0x00)//������
#define MAX7219_DECODE_MODE_DIG0    (0x01)//����λ0
#define MAX7219_DECODE_MODE_0_3     (0x0F)//����λ0-3
#define MAX7219_DECODE_MODE_0_7     (0xFF)//����λ0-7

#define MAX7219_SCAN_LIMIT_MAX      (LED_POS_MAX - 1)//ֻɨ��ǰ�ĸ�

#define LED_SEG_NUM_HEX_MAX         (0xFFFFu)
#define LED_SEG_NUM_OCT_MAX         (9999u)

static uchar g_led_mirror = 0;
uchar LED_DISP_MEM[LED_POS_MAX] = {0};
uint16 LED_FLASH_TMR[LED_POS_MAX] = {0};//��˸

#define LED_MIRROR_POS(pos) (pos = (g_led_mirror ? (LED_POS_MAX - 1 - pos) : pos))
#define LED_MIRROR_SEG(seg) (seg = (g_led_mirror ? LED_SEGB_MIRROR[seg] : seg))

uchar code LED_SEGB_MIRROR[LED_SEGB_MAX] = 
{
    LED_SEGB_G,
    LED_SEGB_C,
    LED_SEGB_B,
    LED_SEGB_A,
    LED_SEGB_F,
    LED_SEGB_E,
    LED_SEGB_D,
    LED_SEGB_DP
};

uchar code LED_SEG_CODE[LED_SEG_MAX] =
{
    0x7E,// 0
    0x30,// 1 |
    0x6D,// 2
    0x79,// 3
    0x33,// 4
    0x5B,// 5
    0x5F,// 6
    0x70,// 7
    0x7F,// 8
    0x7B,// 9
    0x77,// A
    0x1F,// b
    0x4E,// C [
    0x3D,// d
    0x4F,// E
    0x47,// F
    0x78,// ]
    0x37,// H
    0x0E,// L
    0x67,// P
    0x1D,// o
    0x42,//AF
    0x60,//AB
    0x0C,//DE
    0x18,//CD
    0x31,//BCG
    0x07,//EFG
    0x00,// Space
    0x80,// DP��
    0x40,// A��
    0x20,// B��
    0x10,// C��
    0x08,// D��
    0x04,// E��
    0x02,// F��
    0x01,// G�� -
};

void max7219_writeb(uchar dat)
{
    uchar i;
    //LED_CS = 0;
    for(i = 8; i >= 1; i--)
    {
        LED_CLK = 0;
        LED_DIN = ((dat & 0x80) ? 0xFF : 0x00);
        dat = dat << 1;
        LED_CLK = 1;
    }
    //LED_CS = 1;
}

void max7219_write(uchar add, uchar dat)
{
    uchar i = 0;
    LED_CS = 0;
    _nop_();
    max7219_writeb(add);
    _nop_();
    max7219_writeb(dat);
    _nop_();
    LED_CS = 1;
}

void max7219_init(void)
{
    max7219_write(MAX7219_ADDR_DECODE_MODE, MAX7219_DECODE_MODE_NONE);
    max7219_write(MAX7219_ADDR_INTENSITY,   LED_MAX_LIGHT);
    max7219_write(MAX7219_ADDR_SCAN_LIMIT,  MAX7219_SCAN_LIMIT_MAX);//Display digits 0 1 2 3
    max7219_write(MAX7219_ADDR_SHUTDOWN,    0x01);
    max7219_write(MAX7219_ADDR_DISPTEST,    0x00);
}

void led_open(void)
{
    max7219_write(MAX7219_ADDR_SHUTDOWN, 0x01);//����ģʽ(����ģʽ��)
}

void led_close(void)
{
    max7219_write(MAX7219_ADDR_SHUTDOWN, 0x00);//����ģʽ(����ģʽ��)
}

void led_set_light(uchar n)
{
    uchar tmp[8] = {0};

    n = ((n > 0x0f) ? 0x0f : n); //0-15
    max7219_write(MAX7219_ADDR_INTENSITY, n);
}

void led_set_mirror(uchar mirror)
{
    g_led_mirror = (mirror ? 1 : 0);
}

uchar led_mirror_segb(uchar segb)
{
    uchar segbc = 0, i = 0;
    for(i=0; i<LED_SEGB_MAX; i++)
    {
        if(segb & (0x01 << i))
        {
            segbc |= (0x01 << LED_SEGB_MIRROR[i]);
        }
    }

    return segbc;
}

void led_set_point(uchar pos, uchar seg, uchar col)
{
    if((pos >= LED_POS_MAX) || (seg >= LED_SEGB_MAX))
    {
        return;
    }

    LED_MIRROR_POS(pos);
    LED_MIRROR_SEG(seg);

    if(col)
    {
        LED_DISP_MEM[pos] |= (uchar)(0x01 << seg);
    }
    else
    {
        LED_DISP_MEM[pos] &= (uchar)(~(0x01 << seg));
    }
}

uchar led_get_point(uchar pos, uchar seg)
{
    uchar ret = 0;

    pos = ((pos >= LED_POS_MAX) ? (LED_POS_MAX - 1) : pos);
    seg = ((seg >= LED_SEGB_MAX) ? (LED_SEGB_MAX - 1) : seg);

    LED_MIRROR_POS(pos);
    LED_MIRROR_SEG(seg);

    ret = (LED_DISP_MEM[pos] & (uchar)(0x01 << seg));
    return ret;
}

void led_update(void)
{
    uchar i = 0;

    static uint16 led_pos_flag0[LED_POS_MAX] = 0;
    static uint16 led_pos_flag1[LED_POS_MAX] = 0;

    for(i = 0; i < LED_POS_MAX; i++)
    {
        if(LED_FLASH_TMR[i])
        {
            if(led_pos_flag0[i] < LED_FLASH_TMR[i])
            {
                led_pos_flag0[i] += 1;
            }
            else
            {
                led_pos_flag0[i] = 0;
                led_pos_flag1[i] = (led_pos_flag1[i] ? 0 : 1);
            }
        }
        else
        {
            led_pos_flag0[i] = 0;
            led_pos_flag1[i] = 0;
        }

        if(led_pos_flag1[i])
        {
            max7219_write(i + 1, LED_SEG_CODE[LED_SEG_NULL]);
        }
        else
        {
            max7219_write(i + 1, LED_DISP_MEM[i]);
        }
    }
}

void led_clear(uchar dat)
{
    uchar i = 0;

    for(i = 0; i < LED_POS_MAX; i++)
    {
        LED_DISP_MEM[i] = dat;
        LED_FLASH_TMR[i] = 0;
    }
}

void led_open_door(uint16 delay)
{
    uchar i = 0, j = 0;
    for(i=0; i<LED_POS_MAX; i++)
    {
        for(j=0; j<LED_SEGB_MAX; j++)
        {
            led_set_point(i, j, 1);
            led_update();
            delay_xms(delay);
        }
    }
}

void led_close_door(uint16 delay)
{
    uchar i = 0, j = 0;
    for(i=0; i<LED_POS_MAX; i++)
    {
        for(j=0; j<LED_SEGB_MAX; j++)
        {
            led_set_point(LED_POS_MAX-1-i, LED_SEGB_MAX-1-j, 0);
            led_update();
            delay_xms(delay);
        }
    }
}

void led_init(void)
{
    max7219_init();

    led_open();
    led_set_light(LED_MAX_LIGHT);
    led_set_mirror(0);

    led_clear(0);
    led_update();
}

uchar led_seg_cidx_get(char chr)
{
    uchar idx = 0;

    if((chr >= '0') && (chr <= '9'))
    {
        idx = chr - '0' + LED_SEG_0;
    }
    else if((chr >= 'A') && (chr <= 'F'))
    {
        idx = chr - 'A' + LED_SEG_A;
    }
    else if((chr >= 'a') && (chr <= 'f'))
    {
        idx = chr - 'a' + LED_SEG_A;
    }
    else if(chr == '-')
    {
        idx = LED_SEG_HL;
    }
    else if(chr == '_')
    {
        idx = LED_SEG_SD;
    }
    else if(chr == '[')
    {
        idx = LED_SEG_LSB;
    }
    else if(chr == ']')
    {
        idx = LED_SEG_RSB;
    }
    else if(chr == '{')
    {
        idx = LED_SEG_BCG;
    }
    else if(chr == '}')
    {
        idx = LED_SEG_EFG;
    }
    else if((chr == 'H') || (chr == 'h'))
    {
        idx = LED_SEG_H;
    }
    else if((chr == 'L') || (chr == 'l'))
    {
        idx = LED_SEG_L;
    }
    else if((chr == 'O') || (chr == 'o'))
    {
        idx = LED_SEG_O;
    }
    else if((chr == 'P') || (chr == 'p'))
    {
        idx = LED_SEG_P;
    }
    else if(chr == ' ')
    {
        idx = LED_SEG_NULL;
    }
#if 0
    else if((chr > 0) && (chr <  LED_SEG_MAX))
    {
        idx = LED_SEG_MIN + chr;
    }
#endif
    else
    {
        idx = LED_SEG_NULL;
    }

    return idx;
}

uchar led_seg_cpy2mem(uchar pos, uchar segc, uchar col, uchar dp)
{
    uchar i = 0;
    if(pos >= LED_POS_MAX)
    {
        return RTN_ERR;
    }

    for(i = 0; i < LED_SEGB_MAX; i++)
    {
        if(segc & (0x01 << i))
        {
            led_set_point(pos, i, col);
        }
        else
        {
            led_set_point(pos, i, !col);
        }
    }

    if(dp)
    {
        led_set_point(pos, LED_SEGB_DP, col);
    }
    else
    {
        led_set_point(pos, LED_SEGB_DP, !col);
    }

    return RTN_OK;
}

uchar led_putc_dp(uchar pos, char chr, uchar col, uchar dp)
{
    uchar segidx = 0;
    if(pos >= LED_POS_MAX)
    {
        return RTN_ERR;
    }

    segidx = led_seg_cidx_get(chr);
    return led_seg_cpy2mem(pos, LED_SEG_CODE[segidx], col, dp);
}

uchar led_putc(uchar pos, char chr, uchar col)
{
    return led_putc_dp(pos, chr, col, 0);
}

uchar led_puts_dp(uchar pos, const uchar *chs, uchar col, uchar dp)
{
    uchar i = 0, p = pos;
    if((pos >= LED_POS_MAX) || (chs == NULL))
    {
        return RTN_ERR;
    }
    while(*chs)
    {
        if(led_putc_dp(p, *chs, col, dp) == RTN_OK)
        {
            p++;
            if(p >= LED_POS_MAX)
            {
                break;
            }
        }
        chs++;
    }

    return RTN_OK;
}

uchar led_puts(uchar pos, const uchar *chs, uchar col)
{
    return led_puts_dp(pos, chs, col, 0);
}

//ֱ����ʾһ������
uchar led_putb(uchar pos, uchar segb, uchar col, uchar andor)
{
    uchar i = 0;
    if(pos >= LED_POS_MAX)
    {
        return RTN_ERR;
    }

    for(i=0; i<LED_SEGB_MAX; i++)
    {        
        if(andor)
        {
            if(segb & (0x01 << i))
            {
                led_set_point(pos, i, col);
            }
        }
        else
        {
            if(segb & (0x01 << i))
            {
                led_set_point(pos, i, col);
            }
            else
            {
                led_set_point(pos, i, !col);
            }
        }
    }

    

    return RTN_OK;
}

uchar led_putbs(uchar pos, uchar *segb, uchar len, uchar col, uchar andor)
{
    uchar i = 0;
    if((pos >= LED_POS_MAX) || ((pos + len) > LED_POS_MAX) || (segb == NULL))
    {
        return RTN_ERR;
    }


    for(i = pos; i < len; i++)
    {
        led_putb(i, segb[i - pos], col, andor);
    }

    return RTN_OK;
}

//���ݶ���������ʾ
uchar led_puti(uchar pos, uchar segi, uchar col)
{
    uchar segb = 0;

    if((pos >= LED_POS_MAX) || (segi >= LED_SEG_MAX))
    {
        return RTN_ERR;
    }

    segb = LED_SEG_CODE[segi];

    //segb = led_mirror_segb(segb);

    led_putb(pos, segb, col, 0);

    return RTN_OK;
}

uchar led_putis(uchar pos, uchar *segi, uchar len, uchar col)
{
    uchar i = 0;
    if((pos >= LED_POS_MAX) || ((pos + len) > LED_POS_MAX) || (segi == NULL))
    {
        return RTN_ERR;
    }


    for(i = pos; i < len; i++)
    {
        led_puti(i, segi[i - pos], col);
    }

    return RTN_OK;
}

uchar led_set_flashc(uchar pos, uint16 flashtmr)
{
    if(pos >= LED_POS_MAX)
    {
        return RTN_ERR;
    }

    LED_MIRROR_POS(pos);

    LED_FLASH_TMR[pos] = flashtmr;
    
    return RTN_OK;
}

