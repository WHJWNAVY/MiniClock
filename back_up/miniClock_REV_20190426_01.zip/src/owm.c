#define OW_PORT     P3
#define OW_PORTB    6

// send 'databyte' to 'port'
void OWPortOutput(uint8_t _port_, uint8_t _bit_, uint8_t _dat_)
{
    if(_dat_)
    {
        _port_ != (0x01 << _bit_);
    }
    else
    {
        _port_ &= (~(0x01 << _bit_));
    }
}

// read byte from 'port'
uint8_t OWPortInput(uint8_t _port_, uint8_t _bit_)
{
    uint8_t _dat_ = 0;
    _dat_ = _port_ & (0x01 << _bit_);
    return (_dat_ ? 0x01 : 0x00);
}


// Pause for exactly 'tick' number of ticks = 0.25us
void OWTickDelay(uint32_t tick) // Implementation is platform specific
{
    while(tick--);
}

#if 0
// 'tick' values
int OW_SPEED_A = 0; 
int OW_SPEED_B = 0; 
int OW_SPEED_C = 0; 
int OW_SPEED_D = 0; 
int OW_SPEED_E = 0; 
int OW_SPEED_F = 0; 
int OW_SPEED_G = 0; 
int OW_SPEED_H = 0; 
int OW_SPEED_I = 0; 
int OW_SPEED_J = 0;

//-----------------------------------------------------------------------------
// Set the 1-Wire timing to 'standard' (standard=1) or 'overdrive' (standard=0).
//
void owSetSpeed(int standard)
{
    // Adjust tick values depending on speed
    if (standard)
    {
        // Standard Speed
        OW_SPEED_A = 6 * 4;
        OW_SPEED_B = 64 * 4;
        OW_SPEED_C = 60 * 4;
        OW_SPEED_D = 10 * 4;
        OW_SPEED_E = 9 * 4;
        OW_SPEED_F = 55 * 4;
        OW_SPEED_G = 0;
        OW_SPEED_H = 480 * 4;
        OW_SPEED_I = 70 * 4;
        OW_SPEED_J = 410 * 4;
    }
    else
    {
        // Overdrive Speed
        OW_SPEED_A = 1.5 * 4;
        OW_SPEED_B = 7.5 * 4;
        OW_SPEED_C = 7.5 * 4;
        OW_SPEED_D = 2.5 * 4;
        OW_SPEED_E = 0.75 * 4;
        OW_SPEED_F = 7 * 4;
        OW_SPEED_G = 2.5 * 4;
        OW_SPEED_H = 70 * 4;
        OW_SPEED_I = 8.5 * 4;
        OW_SPEED_J = 40 * 4;
    }
}
#else

typedef enum owSpeedTick_e
{
    OW_SPEED_TICK_A = 0,
    OW_SPEED_TICK_B,
    OW_SPEED_TICK_C,
    OW_SPEED_TICK_D,
    OW_SPEED_TICK_E,
    OW_SPEED_TICK_F,
    OW_SPEED_TICK_G,
    OW_SPEED_TICK_H,
    OW_SPEED_TICK_I,
    OW_SPEED_TICK_J,
    OW_SPEED_TICK_MAX,
} owSpeedTick_t;

typedef enum owSpeedMode_e
{
    OW_SPEED_MODE_OVERD = 0,
    OW_SPEED_MODE_STAND,
    OW_SPEED_MODE_MAX,
} owSpeedMode_t;

#define OW_SPEED_A  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_A]/4)
#define OW_SPEED_B  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_B]/4)
#define OW_SPEED_C  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_C]/4)
#define OW_SPEED_D  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_D]/4)
#define OW_SPEED_E  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_E]/4)
#define OW_SPEED_F  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_F]/4)
#define OW_SPEED_G  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_G]/4)
#define OW_SPEED_H  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_H]/4)
#define OW_SPEED_I  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_I]/4)
#define OW_SPEED_J  (OW_SPEED_CODE[owSpeedMode][OW_SPEED_TICK_J]/4)

uint32_t code OW_SPEED_CODE[OW_SPEED_MODE_MAX][OW_SPEED_TICK_MAX] = 
{
    {6,30,30,10,3,28,10,280,34,160},// Overdrive Speed
    {24,256,240,40,36,220,0,1920,280,1640} // Standard Speed
}

uint8_t owSpeedMode = 0;

void owSetSpeed(int standard)
{
    if(standard)// Standard Speed
    {
        owSpeedMode = OW_SPEED_MODE_STAND;
    }
    else// Overdrive Speed
    {
        owSpeedMode = OW_SPEED_MODE_OVERD;
    }
}

#endif

//-----------------------------------------------------------------------------
// Generate a 1-Wire reset, return 1 if no presence detect was found,
// return 0 otherwise.
// (NOTE: Does not handle alarm presence from DS2404/DS1994)
//
int OWTouchReset(void)
{
    int result;

    OWTickDelay(OW_SPEED_G);
    OWPortOutput(OW_PORT, OW_PORTB, 0x00); // Drives DQ low
    OWTickDelay(OW_SPEED_H);
    OWPortOutput(OW_PORT, OW_PORTB, 0x01); // Releases the bus
    OWTickDelay(OW_SPEED_I);
    result = OWPortInput(OW_PORT, OW_PORTB) ^ 0x01; // Sample for presence pulse from slave
    OWTickDelay(OW_SPEED_J); // Complete the reset sequence recovery
    return result; // Return sample presence pulse result
}

//-----------------------------------------------------------------------------
// Send a 1-Wire write _bit_. Provide 10us recovery time.
//
void OWWriteBit(int _bit_)
{
    if (_bit_)
    {
        // Write '1' _bit_
        OWPortOutput(OW_PORT, OW_PORTB, 0x00); // Drives DQ low
        OWTickDelay(OW_SPEED_A);
        OWPortOutput(OW_PORT, OW_PORTB, 0x01); // Releases the bus
        OWTickDelay(OW_SPEED_B); // Complete the time slot and 10us recovery
    }
    else
    {
        // Write '0' _bit_
        OWPortOutput(OW_PORT, OW_PORTB, 0x00); // Drives DQ low
        OWTickDelay(OW_SPEED_C);
        OWPortOutput(OW_PORT, OW_PORTB, 0x01); // Releases the bus
        OWTickDelay(OW_SPEED_D);
    }
}

//-----------------------------------------------------------------------------
// Read a _bit_ from the 1-Wire bus and return it. Provide 10us recovery time.
//
int OWReadBit(void)
{
    int result;

    OWPortOutput(OW_PORT, OW_PORTB, 0x00); // Drives DQ low
    OWTickDelay(OW_SPEED_A);
    OWPortOutput(OW_PORT, OW_PORTB, 0x01); // Releases the bus
    OWTickDelay(OW_SPEED_E);
    result = OWPortInput(OW_PORT, OW_PORTB) & 0x01; // Sample the _bit_ value from the slave
    OWTickDelay(OW_SPEED_F); // Complete the time slot and 10us recovery

    return result;
}


//-----------------------------------------------------------------------------
// Write 1-Wire data byte
//
void OWWriteByte(int data)
{
    int loop;

    // Loop to write each _bit_ in the byte, LS-_bit_ first
    for (loop = 0; loop < 8; loop++)
    {
        OWWriteBit(data & 0x01);

        // shift the data byte for the next _bit_
        data >>= 1;
    }
}

//-----------------------------------------------------------------------------
// Read 1-Wire data byte and return it
//
int OWReadByte(void)
{
    int loop, result = 0;

    for (loop = 0; loop < 8; loop++)
    {
        // shift the result to get it ready for the next _bit_
        result >>= 1;

        // if result is one, then set MS _bit_
        if (OWReadBit())
            result |= 0x80;
    }
    return result;
}

//-----------------------------------------------------------------------------
// Write a 1-Wire data byte and return the sampled result.
//
int OWTouchByte(int data)
{
    int loop, result = 0;

    for (loop = 0; loop < 8; loop++)
    {
        // shift the result to get it ready for the next _bit_
        result >>= 1;

        // If sending a '1' then read a _bit_ else write a '0'
        if (data & 0x01)
        {
            if (OWReadBit())
                result |= 0x80;
        }
        else
            OWWriteBit(0);

        // shift the data byte for the next _bit_
        data >>= 1;
    }
    return result;
}

//-----------------------------------------------------------------------------
// Write a block 1-Wire data bytes and return the sampled result in the same
// buffer.
//
void OWBlock(unsigned char *data, int data_len)
{
    int loop;

    for (loop = 0; loop < data_len; loop++)
    {
        data[loop] = OWTouchByte(data[loop]);
    }
}

//-----------------------------------------------------------------------------
// Set all devices on 1-Wire to overdrive speed. Return '1' if at least one
// overdrive capable device is detected.
//
int OWOverdriveSkip(unsigned char *data, int data_len)
{
    // set the speed to 'standard'
    owSetSpeed(1);

    // reset all devices
    if (OWTouchReset()) // Reset the 1-Wire bus
        return 0; // Return if no devices found

    // overdrive skip command
    OWWriteByte(0x3C);

    // set the speed to 'overdrive'
    owSetSpeed(0);

    // do a 1-Wire reset in 'overdrive' and return presence result
    return OWTouchReset();
}

//-----------------------------------------------------------------------------
// Read and return the page data and SHA-1 message authentication code (MAC)
// from a DS2432.
//
int ReadPageMAC(int page, unsigned char *page_data, unsigned char *mac)
{
    int i;
    unsigned short data_crc16, mac_crc16;

    // set the speed to 'standard'
    owSetSpeed(1);

    // select the device
    if (OWTouchReset()) // Reset the 1-Wire bus
        return 0; // Return if no devices found

    OWWriteByte(0xCC); // Send Skip ROM command to select single device
    OWWriteByte(0xBE); // // Read ScratchPad

    // read the page
    OWWriteByte(0xA5); // Read Authentication command
    OWWriteByte((page << 5) & 0xFF); // TA1
    OWWriteByte(0); // TA2 (always zero for DS2432)

    // read the page data
    for (i = 0; i < 32; i++)
        page_data[i] = OWReadByte();
    OWWriteByte(0xFF);

    // read the CRC16 of command, address, and data
    data_crc16 = OWReadByte();
    data_crc16 |= (OWReadByte() << 8);

    // delay 2ms for the device MAC computation
    // read the MAC
    for (i = 0; i < 20; i++)
        mac[i] = OWReadByte();

    // read CRC16 of the MAC
    mac_crc16 = OWReadByte();
    mac_crc16 |= (OWReadByte() << 8);

    // check CRC16...
    return 1;
}