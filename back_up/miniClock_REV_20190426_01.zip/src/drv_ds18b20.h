/*-----------------------------------------------
               DS18b20��������
------------------------------------------------*/
#ifndef __DRV_DS18B20_H__
#define __DRV_DS18B20_H__

#include "common.h"

extern void ds18b20_init(void);//��ʼ��
extern void ds18b20_write_eeprom(uint8_t temph,uint8_t templ,uint8_t reg_ctrl);
extern void ds18b20_read_temp(uint8_t *sign ,uint16_t *interger ,uint16_t *decimal);
#endif /*DS18B20*/

